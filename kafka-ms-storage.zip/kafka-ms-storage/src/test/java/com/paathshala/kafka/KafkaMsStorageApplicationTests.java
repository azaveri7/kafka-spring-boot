package com.paathshala.kafka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaMsStorageApplicationTests {

	@Test
	void contextLoads() {
	}

}
