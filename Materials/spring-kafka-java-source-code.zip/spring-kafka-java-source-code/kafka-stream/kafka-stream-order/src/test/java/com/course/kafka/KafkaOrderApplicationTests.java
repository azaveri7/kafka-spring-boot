package com.course.kafka;

import org.junit.jupiter.api.Test;

class KafkaOrderApplicationTests {

	@Test
	void contextLoads() {
		var d = ((double) 4 / 5) * 100;
		System.out.println(d);

	}

}
