package com.course.kafka.kafkapattern;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaPatternApplicationTests {

	@Test
	void contextLoads() {
	}

}
