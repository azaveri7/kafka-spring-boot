package com.course.kafka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaCoreConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
